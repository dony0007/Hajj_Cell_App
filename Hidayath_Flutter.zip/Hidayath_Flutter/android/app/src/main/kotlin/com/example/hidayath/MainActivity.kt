package com.example.hidayath

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
